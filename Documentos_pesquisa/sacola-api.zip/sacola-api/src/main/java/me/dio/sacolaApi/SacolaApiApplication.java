package me.dio.sacolaApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SacolaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SacolaApiApplication.class, args);
	}

}
